import React, { useState } from 'react';
import { Image } from 'react-native';

// Telas principais
import HomeScreen from './Screens/HomeScreen';
import LoginScreen from './Screens/LoginScreen';
import DashboardScreen from './Screens/DashboardScreen';
import SobreScreen from './Screens/SobreScreen';

// ALUNOS
import CadastroAlunoScreen from './Screens/CadastroAlunoScreen';
import ConsultaAlunosScreen from './Screens/ConsultaAlunosScreen';
import EditarAlunoScreen from './Screens/EditarAlunoScreen';

// PROFESSORES
import CadastroProfessorScreen from './Screens/CadastroProfessorScreen';
import ConsultaProfessoresScreen from './Screens/ConsultaProfessoresScreen';
import EditarProfessorScreen from './Screens/EditarProfessorScreen';

// TURMAS
import CadastroTurmaScreen from './Screens/CadastroTurmaScreen';
import ConsultaTurmasScreen from './Screens/ConsultaTurmasScreen';
import EditarTurmaScreen from './Screens/EditarTurmaScreen';

// CURSOS
import CadastroCursoScreen from './Screens/CadastroCursoScreen';
import ConsultaCursosScreen from './Screens/ConsultaCursosScreen';
import EditarCursoScreen from './Screens/EditarCursoScreen';

// DISCIPLINAS
import CadastroDisciplinaScreen from './Screens/CadastroDisciplinaScreen';
import ConsultaDisciplinasScreen from './Screens/ConsultaDisciplinasScreen';
import EditarDisciplinaScreen from './Screens/EditarDisciplinaScreen';

// MATRÍCULAS
import CadastroMatriculaScreen from './Screens/CadastroMatriculaScreen';
import ConsultaMatriculasScreen from './Screens/ConsultaMatriculasScreen';
import EditarMatriculaScreen from './Screens/EditarMatriculaScreen';

// RESPONSÁVEIS
import CadastroResponsavelScreen from './Screens/CadastroResponsavelScreen';
import ConsultaResponsaveisScreen from './Screens/ConsultaResponsaveisScreen';
import EditarResponsavelScreen from './Screens/EditarResponsavelScreen';

// AVALIAÇÕES
import CadastroAvaliacaoScreen from './Screens/CadastroAvaliacaoScreen';
import ConsultaAvaliacoesScreen from './Screens/ConsultaAvaliacoesScreen';
import EditarAvaliacaoScreen from './Screens/EditarAvaliacaoScreen';

// COORDENADORES
import CadastroCoordenadorScreen from './Screens/CadastroCoordenadorScreen';
import ConsultaCoordenadoresScreen from './Screens/ConsultaCoordenadoresScreen';
import EditarCoordenadorScreen from './Screens/EditarCoordenadorScreen';

// BOLETINS
import CadastroBoletimScreen from './Screens/CadastroBoletimScreen';
import ConsultaBoletinsScreen from './Screens/ConsultaBoletinsScreen';
import EditarBoletimScreen from './Screens/EditarBoletimScreen';


import logo from './logo.png';

export default function App() {

  // --------------------------------
  // CONTROLE DA NAVEGAÇÃO
  // --------------------------------

  const [tela, setTela] = useState('home');

  const [usuario, setUsuario] = useState(null);

  const [dadosSelecionados, setDadosSelecionados] = useState(null);


  // --------------------------------
  // DADOS DOS ALUNOS
  // --------------------------------

  const [alunos, setAlunos] = useState([
    {
      id: 1,
      nome: 'Ana Luiza',
      email: 'ana@email.com',
      curso: 'Desenvolvimento de Sistemas',
      turma: '3º A',
    },
    {
      id: 2,
      nome: 'João Pedro',
      email: 'joao@email.com',
      curso: 'Desenvolvimento de Sistemas',
      turma: '2º B',
    },
  ]);


  // --------------------------------
  // DADOS DOS PROFESSORES
  // --------------------------------

  const [professores, setProfessores] = useState([
    {
      id: 1,
      nome: 'Carlos Eduardo',
      email: 'carlos@email.com',
      disciplina: 'Programação',
    },
    {
      id: 2,
      nome: 'Mariana Silva',
      email: 'mariana@email.com',
      disciplina: 'Banco de Dados',
    },
  ]);


  // --------------------------------
  // DADOS DAS TURMAS
  // --------------------------------

  const [turmas, setTurmas] = useState([
    {
      id: 1,
      nome: '3º A',
      curso: 'Desenvolvimento de Sistemas',
      ano: '2026',
    },
    {
      id: 2,
      nome: '2º B',
      curso: 'Desenvolvimento de Sistemas',
      ano: '2026',
    },
  ]);


  // --------------------------------
  // DADOS DOS CURSOS
  // --------------------------------

  const [cursos, setCursos] = useState([
    {
      id: 1,
      nome: 'Desenvolvimento de Sistemas',
      descricao: 'Curso Técnico em Desenvolvimento de Sistemas',
    },
    {
      id: 2,
      nome: 'Recursos Humanos',
      descricao: 'Curso Técnico em Recursos Humanos',
    },
    {
      id: 3,
      nome: 'Comércio Exterior',
      descricao: 'Curso Técnico em Comércio Exterior',
    },
    {
      id: 4,
      nome: 'Farmácia',
      descricao: 'Curso Técnico em Farmácia',
    },
    {
      id: 5,
      nome: 'Agronegócio',
      descricao: 'Curso Técnico em Agronegócio',
    },
  ]);


  // --------------------------------
  // DADOS DAS DISCIPLINAS
  // --------------------------------

  const [disciplinas, setDisciplinas] = useState([
    // Desenvolvimento de Sistemas
    {
      id: 1,
      nome: 'Algoritmos e Lógica de Programação',
      curso: 'Desenvolvimento de Sistemas',
    },
    {
      id: 2,
      nome: 'Modelagem e Banco de Dados',
      curso: 'Desenvolvimento de Sistemas',
    },
    {
      id: 3,
      nome: 'Engenharia de Software e Requisitos',
      curso: 'Desenvolvimento de Sistemas',
    },
    {
      id: 4,
      nome: 'Programação Orientada a Objetos',
      curso: 'Desenvolvimento de Sistemas',
    },
    {
      id: 5,
      nome: 'Desenvolvimento Web Front-End',
      curso: 'Desenvolvimento de Sistemas',
    },
    {
      id: 6,
      nome: 'Estrutura de Dados',
      curso: 'Desenvolvimento de Sistemas',
    },
    {
      id: 7,
      nome: 'Desenvolvimento Web Back-End',
      curso: 'Desenvolvimento de Sistemas',
    },
    {
      id: 8,
      nome: 'Arquitetura de Computadores e SO',
      curso: 'Desenvolvimento de Sistemas',
    },
    {
      id: 9,
      nome: 'Desenvolvimento de Aplicações Mobile',
      curso: 'Desenvolvimento de Sistemas',
    },
    {
      id: 10,
      nome: 'Segurança da Informação e DevOps',
      curso: 'Desenvolvimento de Sistemas',
    },

    // Recursos Humanos
    {
      id: 11,
      nome: 'Rotinas de Departamento Pessoal',
      curso: 'Recursos Humanos',
    },
    {
      id: 12,
      nome: 'Recrutamento e Seleção de Pessoas',
      curso: 'Recursos Humanos',
    },
    {
      id: 13,
      nome: 'Cargos, Salários e Remuneração',
      curso: 'Recursos Humanos',
    },
    {
      id: 14,
      nome: 'Treinamento e Desenvolvimento de RH',
      curso: 'Recursos Humanos',
    },
    {
      id: 15,
      nome: 'Legislação Trabalhista e Previdenciária',
      curso: 'Recursos Humanos',
    },

    // Comércio Exterior
    {
      id: 16,
      nome: 'Sistemática de Importação e Exportação',
      curso: 'Comércio Exterior',
    },
    {
      id: 17,
      nome: 'Logística e Transportes Internacionais',
      curso: 'Comércio Exterior',
    },
    {
      id: 18,
      nome: 'Legislação e Direito Aduaneiro',
      curso: 'Comércio Exterior',
    },
  ]);


  // --------------------------------
  // DADOS DAS MATRÍCULAS
  // --------------------------------

  const [matriculas, setMatriculas] = useState([]);


  // --------------------------------
  // DADOS DOS RESPONSÁVEIS
  // --------------------------------

  const [responsaveis, setResponsaveis] = useState([
    {
      id: 1,
      nome: 'Maria Oliveira',
      aluno: 'Ana Luiza',
      telefone: '(12) 99999-9999',
    },
  ]);


  // --------------------------------
  // DADOS DAS AVALIAÇÕES
  // --------------------------------

  const [avaliacoes, setAvaliacoes] = useState([
    {
      id: 1,
      aluno: 'Ana Luiza',
      disciplina: 'Algoritmos e Lógica de Programação',
      nota: '8,5',
    },
  ]);


  // --------------------------------
  // DADOS DOS COORDENADORES
  // --------------------------------

  const [coordenadores, setCoordenadores] = useState([
    {
      id: 1,
      nome: 'Coordenador Geral',
      email: 'coordenacao@davinci.com',
    },
  ]);


  // --------------------------------
  // DADOS DOS BOLETINS
  // --------------------------------

  const [boletins, setBoletins] = useState([
    {
      id: 1,
      aluno: 'Ana Luiza',
      media: '8,5',
      situacao: 'Aprovada',
    },
  ]);


  // --------------------------------
  // FUNÇÃO DE NAVEGAÇÃO
  // --------------------------------

  function navegar(nomeTela, dados = null) {
    setDadosSelecionados(dados);
    setTela(nomeTela);
  }


  // --------------------------------
  // LOGIN
  // --------------------------------

  function fazerLogin(perfil, nome) {
    setUsuario({
      perfil,
      nome,
    });

    setTela('dashboard');
  }


  // --------------------------------
  // SAIR
  // --------------------------------

  function sair() {
    setUsuario(null);
    setDadosSelecionados(null);
    setTela('home');
  }


  // ==========================================
  // TELAS
  // ==========================================


  // HOME
  if (tela === 'home') {
    return (
      <HomeScreen
        navegar={navegar}
        logo={logo}
      />
    );
  }


  // SOBRE
  if (tela === 'sobre') {
    return (
      <SobreScreen
        navegar={navegar}
      />
    );
  }


  // LOGIN
  if (tela === 'login') {
    return (
      <LoginScreen
        navegar={navegar}
        fazerLogin={fazerLogin}
      />
    );
  }


  // DASHBOARD
  if (tela === 'dashboard') {
    return (
      <DashboardScreen
        navegar={navegar}
        usuario={usuario}
        sair={sair}
      />
    );
  }


  // ==========================================
  // ALUNOS
  // ==========================================

  if (tela === 'cadastroAluno') {
    return (
      <CadastroAlunoScreen
        alunos={alunos}
        setAlunos={setAlunos}
        cursos={cursos}
        turmas={turmas}
        navegar={navegar}
      />
    );
  }

  if (tela === 'consultaAlunos') {
    return (
      <ConsultaAlunosScreen
        alunos={alunos}
        setAlunos={setAlunos}
        navegar={navegar}
      />
    );
  }

  if (tela === 'editarAluno') {
    return (
      <EditarAlunoScreen
        aluno={dadosSelecionados}
        alunos={alunos}
        setAlunos={setAlunos}
        cursos={cursos}
        turmas={turmas}
        navegar={navegar}
      />
    );
  }


  // ==========================================
  // PROFESSORES
  // ==========================================

  if (tela === 'cadastroProfessor') {
    return (
      <CadastroProfessorScreen
        professores={professores}
        setProfessores={setProfessores}
        navegar={navegar}
      />
    );
  }

  if (tela === 'consultaProfessores') {
    return (
      <ConsultaProfessoresScreen
        professores={professores}
        setProfessores={setProfessores}
        navegar={navegar}
      />
    );
  }

  if (tela === 'editarProfessor') {
    return (
      <EditarProfessorScreen
        professor={dadosSelecionados}
        professores={professores}
        setProfessores={setProfessores}
        navegar={navegar}
      />
    );
  }


  // ==========================================
  // TURMAS
  // ==========================================

  if (tela === 'cadastroTurma') {
    return (
      <CadastroTurmaScreen
        turmas={turmas}
        setTurmas={setTurmas}
        cursos={cursos}
        navegar={navegar}
      />
    );
  }

  if (tela === 'consultaTurmas') {
    return (
      <ConsultaTurmasScreen
        turmas={turmas}
        setTurmas={setTurmas}
        navegar={navegar}
      />
    );
  }

  if (tela === 'editarTurma') {
    return (
      <EditarTurmaScreen
        turma={dadosSelecionados}
        turmas={turmas}
        setTurmas={setTurmas}
        cursos={cursos}
        navegar={navegar}
      />
    );
  }


  // ==========================================
  // CURSOS
  // ==========================================

  if (tela === 'cadastroCurso') {
    return (
      <CadastroCursoScreen
        cursos={cursos}
        setCursos={setCursos}
        navegar={navegar}
      />
    );
  }

  if (tela === 'consultaCursos') {
    return (
      <ConsultaCursosScreen
        cursos={cursos}
        setCursos={setCursos}
        navegar={navegar}
      />
    );
  }

  if (tela === 'editarCurso') {
    return (
      <EditarCursoScreen
        curso={dadosSelecionados}
        cursos={cursos}
        setCursos={setCursos}
        navegar={navegar}
      />
    );
  }


  // ==========================================
  // DISCIPLINAS
  // ==========================================

  if (tela === 'cadastroDisciplina') {
    return (
      <CadastroDisciplinaScreen
        disciplinas={disciplinas}
        setDisciplinas={setDisciplinas}
        cursos={cursos}
        navegar={navegar}
      />
    );
  }

  if (tela === 'consultaDisciplinas') {
    return (
      <ConsultaDisciplinasScreen
        disciplinas={disciplinas}
        setDisciplinas={setDisciplinas}
        navegar={navegar}
      />
    );
  }

  if (tela === 'editarDisciplina') {
    return (
      <EditarDisciplinaScreen
        disciplina={dadosSelecionados}
        disciplinas={disciplinas}
        setDisciplinas={setDisciplinas}
        cursos={cursos}
        navegar={navegar}
      />
    );
  }


  // ==========================================
  // MATRÍCULAS
  // ==========================================

  if (tela === 'cadastroMatricula') {
    return (
      <CadastroMatriculaScreen
        matriculas={matriculas}
        setMatriculas={setMatriculas}
        alunos={alunos}
        cursos={cursos}
        navegar={navegar}
      />
    );
  }

  if (tela === 'consultaMatriculas') {
    return (
      <ConsultaMatriculasScreen
        matriculas={matriculas}
        setMatriculas={setMatriculas}
        navegar={navegar}
      />
    );
  }

  if (tela === 'editarMatricula') {
    return (
      <EditarMatriculaScreen
        matricula={dadosSelecionados}
        matriculas={matriculas}
        setMatriculas={setMatriculas}
        alunos={alunos}
        cursos={cursos}
        navegar={navegar}
      />
    );
  }


  // ==========================================
  // RESPONSÁVEIS
  // ==========================================

  if (tela === 'cadastroResponsavel') {
    return (
      <CadastroResponsavelScreen
        responsaveis={responsaveis}
        setResponsaveis={setResponsaveis}
        alunos={alunos}
        navegar={navegar}
      />
    );
  }

  if (tela === 'consultaResponsaveis') {
    return (
      <ConsultaResponsaveisScreen
        responsaveis={responsaveis}
        setResponsaveis={setResponsaveis}
        navegar={navegar}
      />
    );
  }

  if (tela === 'editarResponsavel') {
    return (
      <EditarResponsavelScreen
        responsavel={dadosSelecionados}
        responsaveis={responsaveis}
        setResponsaveis={setResponsaveis}
        alunos={alunos}
        navegar={navegar}
      />
    );
  }


  // ==========================================
  // AVALIAÇÕES
  // ==========================================

  if (tela === 'cadastroAvaliacao') {
    return (
      <CadastroAvaliacaoScreen
        avaliacoes={avaliacoes}
        setAvaliacoes={setAvaliacoes}
        alunos={alunos}
        disciplinas={disciplinas}
        navegar={navegar}
      />
    );
  }

  if (tela === 'consultaAvaliacoes') {
    return (
      <ConsultaAvaliacoesScreen
        avaliacoes={avaliacoes}
        setAvaliacoes={setAvaliacoes}
        navegar={navegar}
      />
    );
  }

  if (tela === 'editarAvaliacao') {
    return (
      <EditarAvaliacaoScreen
        avaliacao={dadosSelecionados}
        avaliacoes={avaliacoes}
        setAvaliacoes={setAvaliacoes}
        alunos={alunos}
        disciplinas={disciplinas}
        navegar={navegar}
      />
    );
  }


  // ==========================================
  // COORDENADORES
  // ==========================================

  if (tela === 'cadastroCoordenador') {
    return (
      <CadastroCoordenadorScreen
        coordenadores={coordenadores}
        setCoordenadores={setCoordenadores}
        navegar={navegar}
      />
    );
  }

  if (tela === 'consultaCoordenadores') {
    return (
      <ConsultaCoordenadoresScreen
        coordenadores={coordenadores}
        setCoordenadores={setCoordenadores}
        navegar={navegar}
      />
    );
  }

  if (tela === 'editarCoordenador') {
    return (
      <EditarCoordenadorScreen
        coordenador={dadosSelecionados}
        coordenadores={coordenadores}
        setCoordenadores={setCoordenadores}
        navegar={navegar}
      />
    );
  }


  // ==========================================
  // BOLETINS
  // ==========================================

  if (tela === 'cadastroBoletim') {
    return (
      <CadastroBoletimScreen
        boletins={boletins}
        setBoletins={setBoletins}
        alunos={alunos}
        navegar={navegar}
      />
    );
  }

  if (tela === 'consultaBoletins') {
    return (
      <ConsultaBoletinsScreen
        boletins={boletins}
        setBoletins={setBoletins}
        navegar={navegar}
      />
    );
  }

  if (tela === 'editarBoletim') {
    return (
      <EditarBoletimScreen
        boletim={dadosSelecionados}
        boletins={boletins}
        setBoletins={setBoletins}
        alunos={alunos}
        navegar={navegar}
      />
    );
  }


  // --------------------------------
  // CASO A TELA NÃO EXISTA
  // --------------------------------

  return (
    <HomeScreen
      navegar={navegar}
      logo={logo}
    />
  );
}