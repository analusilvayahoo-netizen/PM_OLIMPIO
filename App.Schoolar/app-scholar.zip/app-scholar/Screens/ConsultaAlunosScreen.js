import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
} from 'react-native';

export default function ConsultaAlunosScreen({
  navegar,
  alunos,
  setAlunos,
}) {

  const [pesquisa, setPesquisa] = useState('');

  const alunosFiltrados = alunos.filter(aluno =>
    aluno.nome.toLowerCase().includes(
      pesquisa.toLowerCase()
    )
  );

  function excluir(id) {

    setAlunos(
      alunos.filter(aluno => aluno.id !== id)
    );
  }

  return (
    <ScrollView style={styles.container}>

      <Text style={styles.titulo}>
        Consulta de Alunos
      </Text>

      <TextInput
        style={styles.input}
        placeholder="Pesquisar aluno..."
        value={pesquisa}
        onChangeText={setPesquisa}
      />

      <TouchableOpacity
        style={styles.cadastrar}
        onPress={() => navegar('cadastroAluno')}
      >
        <Text style={styles.cadastrarTexto}>
          + CADASTRAR ALUNO
        </Text>
      </TouchableOpacity>

      {alunosFiltrados.length === 0 && (
        <Text style={styles.vazio}>
          Nenhum aluno encontrado.
        </Text>
      )}

      {alunosFiltrados.map(aluno => (

        <View
          key={aluno.id}
          style={styles.card}
        >

          <Text style={styles.nome}>
            {aluno.nome}
          </Text>

          <Text>
            E-mail: {aluno.email}
          </Text>

          <Text>
            Curso: {aluno.curso}
          </Text>

          <Text>
            Turma: {aluno.turma}
          </Text>

          <View style={styles.acoes}>

            <TouchableOpacity
              style={styles.editar}
              onPress={() =>
                navegar('editarAluno', aluno)
              }
            >
              <Text style={styles.acaoTexto}>
                EDITAR
              </Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.excluir}
              onPress={() => excluir(aluno.id)}
            >
              <Text style={styles.acaoTexto}>
                EXCLUIR
              </Text>
            </TouchableOpacity>

          </View>

        </View>

      ))}

      <TouchableOpacity
        onPress={() => navegar('dashboard')}
      >
        <Text style={styles.voltar}>
          Voltar ao menu
        </Text>
      </TouchableOpacity>

    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFAFA',
    padding: 20,
  },

  titulo: {
    fontSize: 27,
    fontWeight: 'bold',
    color: '#0D2C1D',
    marginBottom: 20,
  },

  input: {
    backgroundColor: '#FFF',
    borderWidth: 1,
    borderColor: '#CCC',
    borderRadius: 10,
    padding: 14,
    marginBottom: 12,
  },

  cadastrar: {
    backgroundColor: '#0D2C1D',
    padding: 15,
    borderRadius: 10,
    alignItems: 'center',
    marginBottom: 20,
  },

  cadastrarTexto: {
    color: '#FFF',
    fontWeight: 'bold',
  },

  card: {
    backgroundColor: '#FFF',
    borderWidth: 1,
    borderColor: '#DDD',
    borderRadius: 10,
    padding: 16,
    marginBottom: 15,
  },

  nome: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0D2C1D',
    marginBottom: 8,
  },

  acoes: {
    flexDirection: 'row',
    marginTop: 15,
    gap: 10,
  },

  editar: {
    backgroundColor: '#0D2C1D',
    padding: 10,
    borderRadius: 7,
    flex: 1,
    alignItems: 'center',
  },

  excluir: {
    backgroundColor: '#777',
    padding: 10,
    borderRadius: 7,
    flex: 1,
    alignItems: 'center',
  },

  acaoTexto: {
    color: '#FFF',
    fontWeight: 'bold',
  },

  vazio: {
    textAlign: 'center',
    marginTop: 30,
    color: '#777',
  },

  voltar: {
    textAlign: 'center',
    color: '#0D2C1D',
    marginTop: 15,
    marginBottom: 30,
  },
});