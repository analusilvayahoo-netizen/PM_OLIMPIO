import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
} from 'react-native';

export default function CadastroAlunoScreen({
  navegar,
  alunos,
  setAlunos,
}) {

  const [nome, setNome] = useState('');
  const [email, setEmail] = useState('');
  const [curso, setCurso] = useState('');
  const [turma, setTurma] = useState('');

  function cadastrar() {

    if (!nome || !email || !curso || !turma) {
      alert('Preencha todos os campos.');
      return;
    }

    const novoAluno = {
      id: Date.now(),
      nome,
      email,
      curso,
      turma,
    };

    setAlunos([...alunos, novoAluno]);

    alert('Aluno cadastrado com sucesso!');

    setNome('');
    setEmail('');
    setCurso('');
    setTurma('');
  }

  return (
    <ScrollView style={styles.container}>

      <Text style={styles.titulo}>
        Cadastro de Aluno
      </Text>

      <Text style={styles.label}>Nome</Text>

      <TextInput
        style={styles.input}
        placeholder="Nome completo"
        value={nome}
        onChangeText={setNome}
      />

      <Text style={styles.label}>E-mail</Text>

      <TextInput
        style={styles.input}
        placeholder="E-mail"
        value={email}
        onChangeText={setEmail}
        keyboardType="email-address"
      />

      <Text style={styles.label}>Curso</Text>

      <TextInput
        style={styles.input}
        placeholder="Curso"
        value={curso}
        onChangeText={setCurso}
      />

      <Text style={styles.label}>Turma</Text>

      <TextInput
        style={styles.input}
        placeholder="Turma"
        value={turma}
        onChangeText={setTurma}
      />

      <TouchableOpacity
        style={styles.botao}
        onPress={cadastrar}
      >
        <Text style={styles.botaoTexto}>
          CADASTRAR
        </Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={styles.botaoSecundario}
        onPress={() => navegar('consultaAlunos')}
      >
        <Text style={styles.textoSecundario}>
          CONSULTAR ALUNOS
        </Text>
      </TouchableOpacity>

      <TouchableOpacity
        onPress={() => navegar('dashboard')}
      >
        <Text style={styles.voltar}>
          Voltar ao menu
        </Text>
      </TouchableOpacity>

    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFAFA',
    padding: 20,
  },

  titulo: {
    fontSize: 27,
    fontWeight: 'bold',
    color: '#0D2C1D',
    marginBottom: 25,
  },

  label: {
    fontWeight: 'bold',
    marginBottom: 7,
    color: '#333',
  },

  input: {
    backgroundColor: '#FFF',
    borderWidth: 1,
    borderColor: '#CCC',
    borderRadius: 10,
    padding: 14,
    marginBottom: 18,
  },

  botao: {
    backgroundColor: '#0D2C1D',
    padding: 16,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 5,
  },

  botaoTexto: {
    color: '#FFF',
    fontWeight: 'bold',
  },

  botaoSecundario: {
    borderWidth: 1,
    borderColor: '#0D2C1D',
    padding: 15,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 12,
  },

  textoSecundario: {
    color: '#0D2C1D',
    fontWeight: 'bold',
  },

  voltar: {
    color: '#0D2C1D',
    textAlign: 'center',
    marginTop: 20,
    marginBottom: 30,
  },
});