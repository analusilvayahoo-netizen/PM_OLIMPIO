import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
} from 'react-native';

export default function CadastroTurmaScreen({
  navegar,
  turmas,
  setTurmas,
}) {
  const [nome, setNome] = useState('');
  const [curso, setCurso] = useState('');
  const [ano, setAno] = useState('');

  function cadastrar() {
    if (!nome || !curso || !ano) {
      alert('Preencha todos os campos.');
      return;
    }

    const novaTurma = {
      id: Date.now(),
      nome,
      curso,
      ano,
    };

    setTurmas([...turmas, novaTurma]);

    alert('Turma cadastrada com sucesso!');

    setNome('');
    setCurso('');
    setAno('');
  }

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.titulo}>Cadastro de Turma</Text>

      <Text style={styles.label}>Nome da turma</Text>
      <TextInput
        style={styles.input}
        placeholder="Ex.: 3º A"
        value={nome}
        onChangeText={setNome}
      />

      <Text style={styles.label}>Curso</Text>
      <TextInput
        style={styles.input}
        placeholder="Curso"
        value={curso}
        onChangeText={setCurso}
      />

      <Text style={styles.label}>Ano</Text>
      <TextInput
        style={styles.input}
        placeholder="Ano"
        value={ano}
        onChangeText={setAno}
        keyboardType="numeric"
      />

      <TouchableOpacity style={styles.botao} onPress={cadastrar}>
        <Text style={styles.botaoTexto}>CADASTRAR</Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={styles.secundario}
        onPress={() => navegar('consultaTurmas')}
      >
        <Text style={styles.secundarioTexto}>
          CONSULTAR TURMAS
        </Text>
      </TouchableOpacity>

      <TouchableOpacity onPress={() => navegar('dashboard')}>
        <Text style={styles.voltar}>Voltar ao menu</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFAFA',
    padding: 20,
  },
  titulo: {
    fontSize: 27,
    fontWeight: 'bold',
    color: '#0D2C1D',
    marginBottom: 25,
  },
  label: {
    fontWeight: 'bold',
    marginBottom: 7,
  },
  input: {
    backgroundColor: '#FFF',
    borderWidth: 1,
    borderColor: '#CCC',
    borderRadius: 10,
    padding: 14,
    marginBottom: 18,
  },
  botao: {
    backgroundColor: '#0D2C1D',
    padding: 16,
    borderRadius: 10,
    alignItems: 'center',
  },
  botaoTexto: {
    color: '#FFF',
    fontWeight: 'bold',
  },
  secundario: {
    borderWidth: 1,
    borderColor: '#0D2C1D',
    padding: 15,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 12,
  },
  secundarioTexto: {
    color: '#0D2C1D',
    fontWeight: 'bold',
  },
  voltar: {
    textAlign: 'center',
    color: '#0D2C1D',
    marginTop: 20,
    marginBottom: 30,
  },
});