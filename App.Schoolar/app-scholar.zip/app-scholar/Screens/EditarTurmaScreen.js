import React, { useState } from 'react';
import {
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
} from 'react-native';

export default function EditarTurmaScreen({
  navegar,
  turma,
  turmas,
  setTurmas,
}) {
  const [nome, setNome] = useState(turma?.nome || '');
  const [curso, setCurso] = useState(turma?.curso || '');
  const [ano, setAno] = useState(turma?.ano || '');

  function salvar() {
    const atualizadas = turmas.map(item => {
      if (item.id === turma.id) {
        return {
          ...item,
          nome,
          curso,
          ano,
        };
      }

      return item;
    });

    setTurmas(atualizadas);

    alert('Turma atualizada com sucesso!');

    navegar('consultaTurmas');
  }

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.titulo}>Editar Turma</Text>

      <Text style={styles.label}>Nome da turma</Text>
      <TextInput
        style={styles.input}
        value={nome}
        onChangeText={setNome}
      />

      <Text style={styles.label}>Curso</Text>
      <TextInput
        style={styles.input}
        value={curso}
        onChangeText={setCurso}
      />

      <Text style={styles.label}>Ano</Text>
      <TextInput
        style={styles.input}
        value={ano}
        onChangeText={setAno}
        keyboardType="numeric"
      />

      <TouchableOpacity style={styles.botao} onPress={salvar}>
        <Text style={styles.botaoTexto}>
          SALVAR ALTERAÇÕES
        </Text>
      </TouchableOpacity>

      <TouchableOpacity
        onPress={() => navegar('consultaTurmas')}
      >
        <Text style={styles.voltar}>Cancelar</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFAFA',
    padding: 20,
  },
  titulo: {
    fontSize: 27,
    fontWeight: 'bold',
    color: '#0D2C1D',
    marginBottom: 25,
  },
  label: {
    fontWeight: 'bold',
    marginBottom: 7,
  },
  input: {
    backgroundColor: '#FFF',
    borderWidth: 1,
    borderColor: '#CCC',
    borderRadius: 10,
    padding: 14,
    marginBottom: 18,
  },
  botao: {
    backgroundColor: '#0D2C1D',
    padding: 16,
    borderRadius: 10,
    alignItems: 'center',
  },
  botaoTexto: {
    color: '#FFF',
    fontWeight: 'bold',
  },
  voltar: {
    textAlign: 'center',
    color: '#0D2C1D',
    marginTop: 20,
  },
});