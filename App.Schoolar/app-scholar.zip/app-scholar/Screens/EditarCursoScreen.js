import React, { useState } from 'react';
import {
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
} from 'react-native';

export default function EditarCursoScreen({
  navegar,
  curso,
  cursos,
  setCursos,
}) {
  const [nome, setNome] = useState(curso?.nome || '');
  const [descricao, setDescricao] = useState(
    curso?.descricao || ''
  );

  function salvar() {
    const atualizados = cursos.map(item => {
      if (item.id === curso.id) {
        return {
          ...item,
          nome,
          descricao,
        };
      }

      return item;
    });

    setCursos(atualizados);

    alert('Curso atualizado com sucesso!');

    navegar('consultaCursos');
  }

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.titulo}>Editar Curso</Text>

      <Text style={styles.label}>Nome do curso</Text>

      <TextInput
        style={styles.input}
        value={nome}
        onChangeText={setNome}
      />

      <Text style={styles.label}>Descrição</Text>

      <TextInput
        style={[styles.input, styles.area]}
        value={descricao}
        onChangeText={setDescricao}
        multiline
      />

      <TouchableOpacity style={styles.botao} onPress={salvar}>
        <Text style={styles.botaoTexto}>
          SALVAR ALTERAÇÕES
        </Text>
      </TouchableOpacity>

      <TouchableOpacity
        onPress={() => navegar('consultaCursos')}
      >
        <Text style={styles.voltar}>Cancelar</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFAFA',
    padding: 20,
  },
  titulo: {
    fontSize: 27,
    fontWeight: 'bold',
    color: '#0D2C1D',
    marginBottom: 25,
  },
  label: {
    fontWeight: 'bold',
    marginBottom: 7,
  },
  input: {
    backgroundColor: '#FFF',
    borderWidth: 1,
    borderColor: '#CCC',
    borderRadius: 10,
    padding: 14,
    marginBottom: 18,
  },
  area: {
    height: 100,
    textAlignVertical: 'top',
  },
  botao: {
    backgroundColor: '#0D2C1D',
    padding: 16,
    borderRadius: 10,
    alignItems: 'center',
  },
  botaoTexto: {
    color: '#FFF',
    fontWeight: 'bold',
  },
  voltar: {
    textAlign: 'center',
    color: '#0D2C1D',
    marginTop: 20,
  },
});