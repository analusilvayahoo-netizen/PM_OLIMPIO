import React, { useState } from 'react';
import {
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  Alert,
} from 'react-native';

export default function CadastroBoletimScreen({
  boletins,
  setBoletins,
  alunos = [],
  navegar,
}) {
  const [aluno, setAluno] = useState('');
  const [media, setMedia] = useState('');
  const [situacao, setSituacao] = useState('');

  function cadastrar() {
    if (!aluno || !media.trim() || !situacao) {
      Alert.alert('Atenção', 'Preencha todos os campos.');
      return;
    }

    setBoletins([
      ...boletins,
      {
        id: Date.now(),
        aluno,
        media,
        situacao,
      },
    ]);

    Alert.alert('Sucesso', 'Boletim cadastrado!');
    setAluno('');
    setMedia('');
    setSituacao('');
  }

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.titulo}>Cadastrar Boletim</Text>

      <Text style={styles.label}>Aluno</Text>

      {alunos.map((item) => (
        <TouchableOpacity
          key={item.id}
          style={[
            styles.opcao,
            aluno === item.nome && styles.selecionado,
          ]}
          onPress={() => setAluno(item.nome)}
        >
          <Text
            style={[
              styles.textoOpcao,
              aluno === item.nome && styles.textoSelecionado,
            ]}
          >
            {item.nome}
          </Text>
        </TouchableOpacity>
      ))}

      <TextInput
        style={styles.input}
        placeholder="Média final"
        value={media}
        onChangeText={setMedia}
        keyboardType="decimal-pad"
      />

      <Text style={styles.label}>Situação</Text>

      {['Aprovado', 'Reprovado', 'Recuperação'].map((item) => (
        <TouchableOpacity
          key={item}
          style={[
            styles.opcao,
            situacao === item && styles.selecionado,
          ]}
          onPress={() => setSituacao(item)}
        >
          <Text
            style={[
              styles.textoOpcao,
              situacao === item && styles.textoSelecionado,
            ]}
          >
            {item}
          </Text>
        </TouchableOpacity>
      ))}

      <TouchableOpacity style={styles.botao} onPress={cadastrar}>
        <Text style={styles.textoBotao}>CADASTRAR</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flexGrow: 1, padding: 25, backgroundColor: '#FFFAFA' },
  titulo: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#0D2C1D',
    marginBottom: 25,
  },
  label: {
    fontWeight: 'bold',
    color: '#0D2C1D',
    marginBottom: 10,
  },
  opcao: {
    backgroundColor: '#FFF',
    borderWidth: 1,
    borderColor: '#D5DDD8',
    padding: 14,
    borderRadius: 10,
    marginBottom: 10,
  },
  selecionado: {
    backgroundColor: '#0D2C1D',
  },
  textoOpcao: {
    color: '#0D2C1D',
    fontWeight: 'bold',
  },
  textoSelecionado: {
    color: '#FFF',
  },
  input: {
    backgroundColor: '#FFF',
    borderWidth: 1,
    borderColor: '#D5DDD8',
    borderRadius: 10,
    padding: 14,
    marginVertical: 15,
  },
  botao: {
    backgroundColor: '#0D2C1D',
    padding: 16,
    borderRadius: 10,
    alignItems: 'center',
  },
  textoBotao: {
    color: '#FFF',
    fontWeight: 'bold',
  },
});