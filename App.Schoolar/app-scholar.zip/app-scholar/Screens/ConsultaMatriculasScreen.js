import React, { useState } from 'react';
import {
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  View,
  StyleSheet,
  Alert,
} from 'react-native';

import { CORES } from './Cores';

export default function ConsultaMatriculasScreen({
  matriculas,
  setMatriculas,
  navegar,
}) {
  const [busca, setBusca] = useState('');

  const lista = matriculas.filter((item) =>
    `${item.aluno} ${item.curso} ${item.ano}`
      .toLowerCase()
      .includes(busca.toLowerCase())
  );

  function excluir(id) {
    Alert.alert(
      'Excluir',
      'Deseja excluir esta matrícula?',
      [
        {
          text: 'Cancelar',
          style: 'cancel',
        },
        {
          text: 'Excluir',
          style: 'destructive',
          onPress: () =>
            setMatriculas(
              matriculas.filter(
                (item) => item.id !== id
              )
            ),
        },
      ]
    );
  }

  return (
    <ScrollView
      contentContainerStyle={styles.container}
      showsVerticalScrollIndicator={false}
    >
      <Text style={styles.titulo}>
        Consultar Matrículas
      </Text>

      <TextInput
        style={styles.input}
        placeholder="Pesquisar matrícula..."
        placeholderTextColor="#999"
        value={busca}
        onChangeText={setBusca}
      />

      {lista.length > 0 ? (
        lista.map((item) => (
          <View
            style={styles.card}
            key={item.id}
          >
            <Text style={styles.nome}>
              {item.aluno}
            </Text>

            <Text style={styles.informacao}>
              Curso: {item.curso}
            </Text>

            <Text style={styles.informacao}>
              Ano: {item.ano}
            </Text>

            <TouchableOpacity
              style={styles.editar}
              onPress={() =>
                navegar(
                  'editarMatricula',
                  item
                )
              }
            >
              <Text style={styles.textoBotao}>
                EDITAR
              </Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.excluir}
              onPress={() =>
                excluir(item.id)
              }
            >
              <Text style={styles.textoBotao}>
                EXCLUIR
              </Text>
            </TouchableOpacity>
          </View>
        ))
      ) : (
        <Text style={styles.semDados}>
          Nenhuma matrícula encontrada.
        </Text>
      )}

      {/* NOVA MATRÍCULA */}
      <TouchableOpacity
        style={styles.botao}
        onPress={() =>
          navegar('cadastroMatricula')
        }
      >
        <Text style={styles.textoBotao}>
          NOVA MATRÍCULA
        </Text>
      </TouchableOpacity>

      {/* VOLTAR */}
      <TouchableOpacity
        style={styles.botaoVoltar}
        onPress={() =>
          navegar('dashboard')
        }
      >
        <Text style={styles.textoVoltar}>
          VOLTAR
        </Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    padding: 25,
    paddingBottom: 40,
    backgroundColor: CORES.fundo,
  },

  titulo: {
    fontSize: 28,
    fontWeight: 'bold',
    color: CORES.verde,
    marginBottom: 20,
  },

  input: {
    backgroundColor: CORES.branco,
    borderWidth: 1,
    borderColor: CORES.borda,
    borderRadius: 10,
    padding: 14,
    marginBottom: 20,
    fontSize: 16,
    color: CORES.verde,
  },

  card: {
    backgroundColor: CORES.branco,
    padding: 18,
    borderRadius: 12,
    marginBottom: 15,
    borderWidth: 1,
    borderColor: CORES.borda,
  },

  nome: {
    fontSize: 18,
    fontWeight: 'bold',
    color: CORES.verde,
    marginBottom: 8,
  },

  informacao: {
    color: CORES.cinza,
    fontSize: 15,
    marginBottom: 4,
  },

  editar: {
    backgroundColor: CORES.verde,
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 12,
  },

  excluir: {
    backgroundColor: '#8B0000',
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 8,
  },

  botao: {
    backgroundColor: CORES.verde,
    padding: 16,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 5,
  },

  textoBotao: {
    color: CORES.branco,
    fontWeight: 'bold',
    fontSize: 15,
  },

  botaoVoltar: {
    backgroundColor: 'transparent',
    borderWidth: 1,
    borderColor: CORES.verde,
    padding: 15,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 12,
  },

  textoVoltar: {
    color: CORES.verde,
    fontSize: 15,
    fontWeight: 'bold',
  },

  semDados: {
    textAlign: 'center',
    color: CORES.cinza,
    fontSize: 16,
    marginVertical: 30,
  },
});