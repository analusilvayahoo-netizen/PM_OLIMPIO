import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  Alert,
} from 'react-native';

export default function ConsultaDisciplinasScreen({
  disciplinas,
  setDisciplinas,
  navegar,
}) {
  const [busca, setBusca] = useState('');

  const lista = disciplinas.filter((item) =>
    `${item.nome} ${item.curso}`
      .toLowerCase()
      .includes(busca.toLowerCase())
  );

  function excluir(id) {
    Alert.alert(
      'Excluir',
      'Deseja realmente excluir esta disciplina?',
      [
        { text: 'Cancelar', style: 'cancel' },
        {
          text: 'Excluir',
          onPress: () =>
            setDisciplinas(disciplinas.filter((item) => item.id !== id)),
        },
      ]
    );
  }

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.titulo}>Consultar Disciplinas</Text>

      <TextInput
        style={styles.input}
        placeholder="Pesquisar disciplina ou curso..."
        value={busca}
        onChangeText={setBusca}
      />

      {lista.map((item) => (
        <View key={item.id} style={styles.card}>
          <Text style={styles.nome}>{item.nome}</Text>
          <Text style={styles.info}>Curso: {item.curso}</Text>

          <TouchableOpacity
            style={styles.editar}
            onPress={() => navegar('editarDisciplina', item)}
          >
            <Text style={styles.textoBotao}>EDITAR</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.excluir}
            onPress={() => excluir(item.id)}
          >
            <Text style={styles.textoBotao}>EXCLUIR</Text>
          </TouchableOpacity>
        </View>
      ))}

      <TouchableOpacity
        style={styles.botao}
        onPress={() => navegar('cadastroDisciplina')}
      >
        <Text style={styles.textoBotao}>NOVA DISCIPLINA</Text>
      </TouchableOpacity>

      <TouchableOpacity onPress={() => navegar('dashboard')}>
        <Text style={styles.voltar}>Voltar</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    padding: 25,
    backgroundColor: '#FFFAFA',
  },
  titulo: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#0D2C1D',
    marginBottom: 20,
  },
  input: {
    backgroundColor: '#FFF',
    borderWidth: 1,
    borderColor: '#D5DDD8',
    borderRadius: 10,
    padding: 14,
    marginBottom: 20,
  },
  card: {
    backgroundColor: '#FFF',
    padding: 18,
    borderRadius: 12,
    marginBottom: 15,
  },
  nome: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0D2C1D',
    marginBottom: 8,
  },
  info: {
    color: '#666',
    marginBottom: 12,
  },
  editar: {
    backgroundColor: '#0D2C1D',
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
    marginBottom: 8,
  },
  excluir: {
    backgroundColor: '#8B0000',
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  botao: {
    backgroundColor: '#0D2C1D',
    padding: 16,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 10,
  },
  textoBotao: {
    color: '#FFF',
    fontWeight: 'bold',
  },
  voltar: {
    textAlign: 'center',
    color: '#666',
    marginTop: 20,
  },
});