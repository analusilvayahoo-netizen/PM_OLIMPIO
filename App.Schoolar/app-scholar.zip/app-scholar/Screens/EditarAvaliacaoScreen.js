import React, { useState } from 'react';
import {
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  Alert,
} from 'react-native';

export default function EditarAvaliacaoScreen({
  avaliacao,
  avaliacoes,
  setAvaliacoes,
  alunos = [],
  disciplinas = [],
  navegar,
}) {
  const [aluno, setAluno] = useState(avaliacao?.aluno || '');
  const [disciplina, setDisciplina] = useState(
    avaliacao?.disciplina || ''
  );
  const [nota, setNota] = useState(avaliacao?.nota || '');

  function salvar() {
    if (!aluno || !disciplina || !nota.trim()) {
      Alert.alert('Atenção', 'Preencha todos os campos.');
      return;
    }

    setAvaliacoes(
      avaliacoes.map((item) =>
        item.id === avaliacao.id
          ? { ...item, aluno, disciplina, nota }
          : item
      )
    );

    Alert.alert('Sucesso', 'Avaliação atualizada!');
    navegar('consultaAvaliacoes');
  }

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.titulo}>Editar Avaliação</Text>

      <Text style={styles.label}>Aluno</Text>

      {alunos.map((item) => (
        <TouchableOpacity
          key={item.id}
          style={[
            styles.opcao,
            aluno === item.nome && styles.selecionado,
          ]}
          onPress={() => setAluno(item.nome)}
        >
          <Text
            style={[
              styles.textoOpcao,
              aluno === item.nome && styles.textoSelecionado,
            ]}
          >
            {item.nome}
          </Text>
        </TouchableOpacity>
      ))}

      <Text style={styles.label}>Disciplina</Text>

      {disciplinas.map((item) => (
        <TouchableOpacity
          key={item.id}
          style={[
            styles.opcao,
            disciplina === item.nome && styles.selecionado,
          ]}
          onPress={() => setDisciplina(item.nome)}
        >
          <Text
            style={[
              styles.textoOpcao,
              disciplina === item.nome && styles.textoSelecionado,
            ]}
          >
            {item.nome}
          </Text>
        </TouchableOpacity>
      ))}

      <TextInput
        style={styles.input}
        placeholder="Nota"
        value={nota}
        onChangeText={setNota}
        keyboardType="decimal-pad"
      />

      <TouchableOpacity style={styles.botao} onPress={salvar}>
        <Text style={styles.textoBotao}>SALVAR</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flexGrow: 1, padding: 25, backgroundColor: '#FFFAFA' },
  titulo: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#0D2C1D',
    marginBottom: 25,
  },
  label: {
    fontWeight: 'bold',
    color: '#0D2C1D',
    marginBottom: 10,
  },
  opcao: {
    backgroundColor: '#FFF',
    borderWidth: 1,
    borderColor: '#D5DDD8',
    padding: 14,
    borderRadius: 10,
    marginBottom: 10,
  },
  selecionado: {
    backgroundColor: '#0D2C1D',
  },
  textoOpcao: {
    color: '#0D2C1D',
    fontWeight: 'bold',
  },
  textoSelecionado: {
    color: '#FFF',
  },
  input: {
    backgroundColor: '#FFF',
    borderWidth: 1,
    borderColor: '#D5DDD8',
    borderRadius: 10,
    padding: 14,
    marginVertical: 15,
  },
  botao: {
    backgroundColor: '#0D2C1D',
    padding: 16,
    borderRadius: 10,
    alignItems: 'center',
  },
  textoBotao: {
    color: '#FFF',
    fontWeight: 'bold',
  },
});