import React from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
} from 'react-native';

export default function DashboardScreen({
  usuario,
  navegar,
  sair,
}) {

  const menus = [
    ['ALUNOS', 'consultaAlunos'],
    ['PROFESSORES', 'consultaProfessores'],
    ['TURMAS', 'consultaTurmas'],
    ['CURSOS', 'consultaCursos'],
    ['DISCIPLINAS', 'consultaDisciplinas'],
    ['MATRÍCULAS', 'consultaMatriculas'],
    ['RESPONSÁVEIS', 'consultaResponsaveis'],
    ['AVALIAÇÕES', 'consultaAvaliacoes'],
    ['COORDENADORES', 'consultaCoordenadores'],
    ['BOLETINS', 'consultaBoletins'],
  ];

  return (
    <ScrollView style={styles.container}>

      <View style={styles.header}>
        <Text style={styles.titulo}>
          App Scholar
        </Text>

        <Text style={styles.usuario}>
          Olá, {usuario?.nome}
        </Text>

        <Text style={styles.perfil}>
          Perfil: {usuario?.perfil}
        </Text>
      </View>

      <Text style={styles.menuTitulo}>
        Menu Principal
      </Text>

      {menus.map(([nome, tela]) => (
        <TouchableOpacity
          key={tela}
          style={styles.botao}
          onPress={() => navegar(tela)}
        >
          <Text style={styles.botaoTexto}>
            {nome}
          </Text>
        </TouchableOpacity>
      ))}

      <TouchableOpacity
        style={styles.sair}
        onPress={sair}
      >
        <Text style={styles.sairTexto}>
          SAIR
        </Text>
      </TouchableOpacity>

    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFAFA',
  },

  header: {
    backgroundColor: '#0D2C1D',
    padding: 25,
    paddingTop: 45,
  },

  titulo: {
    color: '#FFF',
    fontSize: 28,
    fontWeight: 'bold',
  },

  usuario: {
    color: '#FFF',
    fontSize: 18,
    marginTop: 15,
  },

  perfil: {
    color: '#DDD',
    marginTop: 5,
  },

  menuTitulo: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#0D2C1D',
    padding: 20,
  },

  botao: {
    backgroundColor: '#FFF',
    borderWidth: 1,
    borderColor: '#D5DDD8',
    borderRadius: 10,
    marginHorizontal: 20,
    marginBottom: 12,
    padding: 18,
  },

  botaoTexto: {
    color: '#0D2C1D',
    fontSize: 16,
    fontWeight: 'bold',
  },

  sair: {
    backgroundColor: '#999',
    padding: 16,
    borderRadius: 10,
    margin: 20,
    alignItems: 'center',
  },

  sairTexto: {
    color: '#FFF',
    fontWeight: 'bold',
  },
});