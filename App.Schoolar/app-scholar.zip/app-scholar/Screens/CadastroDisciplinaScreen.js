import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  Alert,
} from 'react-native';

export default function CadastroDisciplinaScreen({
  disciplinas,
  setDisciplinas,
  cursos = [],
  navegar,
}) {
  const [nome, setNome] = useState('');
  const [curso, setCurso] = useState('');

  function cadastrar() {
    if (!nome.trim() || !curso) {
      Alert.alert('Atenção', 'Preencha o nome e selecione o curso.');
      return;
    }

    const novaDisciplina = {
      id: Date.now(),
      nome: nome.trim(),
      curso,
    };

    setDisciplinas([...disciplinas, novaDisciplina]);

    Alert.alert('Sucesso', 'Disciplina cadastrada!');

    setNome('');
    setCurso('');
  }

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.titulo}>Cadastrar Disciplina</Text>

      <Text style={styles.label}>Nome da disciplina</Text>
      <TextInput
        style={styles.input}
        placeholder="Digite o nome"
        value={nome}
        onChangeText={setNome}
      />

      <Text style={styles.label}>Selecione o curso</Text>

      {cursos.map((item) => (
        <TouchableOpacity
          key={item.id}
          style={[
            styles.opcao,
            curso === item.nome && styles.opcaoSelecionada,
          ]}
          onPress={() => setCurso(item.nome)}
        >
          <Text
            style={[
              styles.textoOpcao,
              curso === item.nome && styles.textoSelecionado,
            ]}
          >
            {item.nome}
          </Text>
        </TouchableOpacity>
      ))}

      <Text style={styles.selecionado}>
        Curso selecionado: {curso || 'Nenhum'}
      </Text>

      <TouchableOpacity style={styles.botao} onPress={cadastrar}>
        <Text style={styles.textoBotao}>CADASTRAR</Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={styles.botaoSecundario}
        onPress={() => navegar('consultaDisciplinas')}
      >
        <Text style={styles.textoSecundario}>CONSULTAR DISCIPLINAS</Text>
      </TouchableOpacity>

      <TouchableOpacity onPress={() => navegar('dashboard')}>
        <Text style={styles.voltar}>Voltar</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    padding: 25,
    backgroundColor: '#FFFAFA',
  },
  titulo: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#0D2C1D',
    marginBottom: 25,
  },
  label: {
    fontWeight: 'bold',
    color: '#0D2C1D',
    marginBottom: 8,
  },
  input: {
    backgroundColor: '#FFF',
    borderWidth: 1,
    borderColor: '#D5DDD8',
    borderRadius: 10,
    padding: 14,
    marginBottom: 20,
  },
  opcao: {
    backgroundColor: '#FFF',
    borderWidth: 1,
    borderColor: '#D5DDD8',
    padding: 14,
    borderRadius: 10,
    marginBottom: 10,
  },
  opcaoSelecionada: {
    backgroundColor: '#0D2C1D',
  },
  textoOpcao: {
    color: '#0D2C1D',
    fontWeight: 'bold',
  },
  textoSelecionado: {
    color: '#FFF',
  },
  selecionado: {
    marginVertical: 15,
    color: '#666',
  },
  botao: {
    backgroundColor: '#0D2C1D',
    padding: 16,
    borderRadius: 10,
    alignItems: 'center',
    marginBottom: 12,
  },
  textoBotao: {
    color: '#FFF',
    fontWeight: 'bold',
  },
  botaoSecundario: {
    borderWidth: 1,
    borderColor: '#0D2C1D',
    padding: 15,
    borderRadius: 10,
    alignItems: 'center',
    marginBottom: 20,
  },
  textoSecundario: {
    color: '#0D2C1D',
    fontWeight: 'bold',
  },
  voltar: {
    textAlign: 'center',
    color: '#666',
  },
});