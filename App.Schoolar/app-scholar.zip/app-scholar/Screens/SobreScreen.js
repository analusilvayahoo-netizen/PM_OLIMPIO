import React from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
} from 'react-native';

export default function SobreScreen({ navegar }) {
  return (
    <View style={styles.container}>

      <Text style={styles.titulo}>Sobre o App Scholar</Text>

      <Text style={styles.texto}>
        O App Scholar é um sistema desenvolvido para
        auxiliar na organização das informações escolares.
      </Text>

      <Text style={styles.texto}>
        O aplicativo permite o gerenciamento de alunos,
        professores, turmas, cursos, disciplinas,
        matrículas, responsáveis, avaliações,
        coordenadores e boletins.
      </Text>

      <TouchableOpacity
        style={styles.botao}
        onPress={() => navegar('home')}
      >
        <Text style={styles.botaoTexto}>VOLTAR</Text>
      </TouchableOpacity>

    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFAFA',
    padding: 25,
    justifyContent: 'center',
  },

  titulo: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#0D2C1D',
    textAlign: 'center',
    marginBottom: 25,
  },

  texto: {
    fontSize: 16,
    color: '#444',
    lineHeight: 25,
    marginBottom: 20,
    textAlign: 'justify',
  },

  botao: {
    backgroundColor: '#0D2C1D',
    padding: 15,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 20,
  },

  botaoTexto: {
    color: '#FFF',
    fontWeight: 'bold',
  },
});