import React, { useState } from 'react';
import {
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
} from 'react-native';

export default function CadastroCursoScreen({
  navegar,
  cursos,
  setCursos,
}) {
  const [nome, setNome] = useState('');
  const [descricao, setDescricao] = useState('');

  function cadastrar() {
    if (!nome || !descricao) {
      alert('Preencha todos os campos.');
      return;
    }

    const novoCurso = {
      id: Date.now(),
      nome,
      descricao,
    };

    setCursos([...cursos, novoCurso]);

    alert('Curso cadastrado com sucesso!');

    setNome('');
    setDescricao('');
  }

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.titulo}>Cadastro de Curso</Text>

      <Text style={styles.label}>Nome do curso</Text>

      <TextInput
        style={styles.input}
        placeholder="Nome do curso"
        value={nome}
        onChangeText={setNome}
      />

      <Text style={styles.label}>Descrição</Text>

      <TextInput
        style={[styles.input, styles.area]}
        placeholder="Descrição do curso"
        value={descricao}
        onChangeText={setDescricao}
        multiline
      />

      <TouchableOpacity style={styles.botao} onPress={cadastrar}>
        <Text style={styles.botaoTexto}>CADASTRAR</Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={styles.secundario}
        onPress={() => navegar('consultaCursos')}
      >
        <Text style={styles.secundarioTexto}>
          CONSULTAR CURSOS
        </Text>
      </TouchableOpacity>

      <TouchableOpacity onPress={() => navegar('dashboard')}>
        <Text style={styles.voltar}>Voltar ao menu</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFAFA',
    padding: 20,
  },
  titulo: {
    fontSize: 27,
    fontWeight: 'bold',
    color: '#0D2C1D',
    marginBottom: 25,
  },
  label: {
    fontWeight: 'bold',
    marginBottom: 7,
  },
  input: {
    backgroundColor: '#FFF',
    borderWidth: 1,
    borderColor: '#CCC',
    borderRadius: 10,
    padding: 14,
    marginBottom: 18,
  },
  area: {
    height: 100,
    textAlignVertical: 'top',
  },
  botao: {
    backgroundColor: '#0D2C1D',
    padding: 16,
    borderRadius: 10,
    alignItems: 'center',
  },
  botaoTexto: {
    color: '#FFF',
    fontWeight: 'bold',
  },
  secundario: {
    borderWidth: 1,
    borderColor: '#0D2C1D',
    padding: 15,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 12,
  },
  secundarioTexto: {
    color: '#0D2C1D',
    fontWeight: 'bold',
  },
  voltar: {
    textAlign: 'center',
    color: '#0D2C1D',
    marginTop: 20,
    marginBottom: 30,
  },
});