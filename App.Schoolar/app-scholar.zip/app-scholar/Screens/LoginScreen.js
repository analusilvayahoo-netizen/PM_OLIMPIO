import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
} from 'react-native';

export default function LoginScreen({ navegar, fazerLogin }) {

  const [nome, setNome] = useState('');
  const [perfil, setPerfil] = useState('');

  function entrar() {

    if (!nome.trim()) {
      alert('Digite seu nome.');
      return;
    }

    if (!perfil) {
      alert('Selecione um perfil.');
      return;
    }

    fazerLogin(perfil, nome);
  }

  return (
    <View style={styles.container}>

      <Text style={styles.titulo}>Login</Text>

      <TextInput
        style={styles.input}
        placeholder="Nome"
        value={nome}
        onChangeText={setNome}
      />

      <Text style={styles.label}>
        Escolha seu perfil:
      </Text>

      <View style={styles.perfis}>

        {['Aluno', 'Responsável', 'Professor', 'Coordenador'].map(
          item => (
            <TouchableOpacity
              key={item}
              style={[
                styles.perfil,
                perfil === item && styles.perfilSelecionado,
              ]}
              onPress={() => setPerfil(item)}
            >
              <Text
                style={[
                  styles.perfilTexto,
                  perfil === item && styles.perfilTextoSelecionado,
                ]}
              >
                {item}
              </Text>
            </TouchableOpacity>
          )
        )}

      </View>

      <TouchableOpacity
        style={styles.botao}
        onPress={entrar}
      >
        <Text style={styles.botaoTexto}>ENTRAR</Text>
      </TouchableOpacity>

      <TouchableOpacity
        onPress={() => navegar('home')}
      >
        <Text style={styles.voltar}>Voltar</Text>
      </TouchableOpacity>

    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFAFA',
    padding: 25,
    justifyContent: 'center',
  },

  titulo: {
    fontSize: 30,
    fontWeight: 'bold',
    color: '#0D2C1D',
    textAlign: 'center',
    marginBottom: 30,
  },

  input: {
    backgroundColor: '#FFF',
    borderWidth: 1,
    borderColor: '#CCC',
    borderRadius: 10,
    padding: 15,
    marginBottom: 20,
  },

  label: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 10,
  },

  perfis: {
    marginBottom: 20,
  },

  perfil: {
    borderWidth: 1,
    borderColor: '#0D2C1D',
    borderRadius: 8,
    padding: 12,
    marginBottom: 8,
  },

  perfilSelecionado: {
    backgroundColor: '#0D2C1D',
  },

  perfilTexto: {
    textAlign: 'center',
    color: '#0D2C1D',
  },

  perfilTextoSelecionado: {
    color: '#FFF',
    fontWeight: 'bold',
  },

  botao: {
    backgroundColor: '#0D2C1D',
    padding: 16,
    borderRadius: 10,
    alignItems: 'center',
  },

  botaoTexto: {
    color: '#FFF',
    fontWeight: 'bold',
  },

  voltar: {
    textAlign: 'center',
    color: '#0D2C1D',
    marginTop: 20,
  },
});