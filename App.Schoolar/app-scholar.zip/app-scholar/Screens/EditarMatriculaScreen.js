import React, { useState } from 'react';
import {
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  Alert,
} from 'react-native';

import { CORES } from './Cores';

export default function EditarMatriculaScreen({
  matricula,
  matriculas,
  setMatriculas,
  alunos = [],
  cursos = [],
  navegar,
}) {
  const [aluno, setAluno] = useState(matricula?.aluno || '');
  const [curso, setCurso] = useState(matricula?.curso || '');
  const [ano, setAno] = useState(matricula?.ano || '');

  function salvar() {
    if (!aluno || !curso || !ano.trim()) {
      Alert.alert(
        'Atenção',
        'Preencha todos os campos.'
      );
      return;
    }

    setMatriculas(
      matriculas.map((item) =>
        item.id === matricula.id
          ? {
              ...item,
              aluno: aluno,
              curso: curso,
              ano: ano.trim(),
            }
          : item
      )
    );

    Alert.alert(
      'Sucesso',
      'Matrícula atualizada!'
    );

    navegar('consultaMatriculas');
  }

  return (
    <ScrollView
      contentContainerStyle={styles.container}
      showsVerticalScrollIndicator={false}
    >
      <Text style={styles.titulo}>
        Editar Matrícula
      </Text>

      {/* ALUNO */}
      <Text style={styles.label}>
        Aluno
      </Text>

      {alunos.length > 0 ? (
        alunos.map((item) => (
          <TouchableOpacity
            key={item.id}
            style={[
              styles.opcao,
              aluno === item.nome && styles.selecionado,
            ]}
            onPress={() => setAluno(item.nome)}
          >
            <Text
              style={[
                styles.textoOpcao,
                aluno === item.nome &&
                  styles.textoSelecionado,
              ]}
            >
              {item.nome}
            </Text>
          </TouchableOpacity>
        ))
      ) : (
        <Text style={styles.semDados}>
          Nenhum aluno cadastrado.
        </Text>
      )}

      {/* CURSO */}
      <Text style={styles.label}>
        Curso
      </Text>

      {cursos.length > 0 ? (
        cursos.map((item) => (
          <TouchableOpacity
            key={item.id}
            style={[
              styles.opcao,
              curso === item.nome && styles.selecionado,
            ]}
            onPress={() => setCurso(item.nome)}
          >
            <Text
              style={[
                styles.textoOpcao,
                curso === item.nome &&
                  styles.textoSelecionado,
              ]}
            >
              {item.nome}
            </Text>
          </TouchableOpacity>
        ))
      ) : (
        <Text style={styles.semDados}>
          Nenhum curso cadastrado.
        </Text>
      )}

      {/* ANO */}
      <Text style={styles.label}>
        Ano
      </Text>

      <TextInput
        style={styles.input}
        value={ano}
        onChangeText={setAno}
        placeholder="Digite o ano"
        placeholderTextColor="#999"
        keyboardType="numeric"
      />

      {/* SALVAR */}
      <TouchableOpacity
        style={styles.botao}
        onPress={salvar}
      >
        <Text style={styles.textoBotao}>
          SALVAR
        </Text>
      </TouchableOpacity>

      {/* CANCELAR */}
      <TouchableOpacity
        style={styles.botaoCancelar}
        onPress={() =>
          navegar('consultaMatriculas')
        }
      >
        <Text style={styles.textoCancelar}>
          CANCELAR
        </Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    padding: 25,
    backgroundColor: CORES.fundo,
    paddingBottom: 40,
  },

  titulo: {
    fontSize: 28,
    fontWeight: 'bold',
    color: CORES.verde,
    marginBottom: 25,
  },

  label: {
    fontSize: 16,
    fontWeight: 'bold',
    color: CORES.verde,
    marginBottom: 10,
    marginTop: 10,
  },

  opcao: {
    backgroundColor: CORES.branco,
    borderWidth: 1,
    borderColor: CORES.borda,
    padding: 14,
    borderRadius: 10,
    marginBottom: 10,
  },

  selecionado: {
    backgroundColor: CORES.verde,
    borderColor: CORES.verde,
  },

  textoOpcao: {
    color: CORES.verde,
    fontWeight: 'bold',
    fontSize: 15,
  },

  textoSelecionado: {
    color: CORES.branco,
  },

  semDados: {
    color: CORES.cinza,
    marginBottom: 15,
    fontStyle: 'italic',
  },

  input: {
    backgroundColor: CORES.branco,
    borderWidth: 1,
    borderColor: CORES.borda,
    borderRadius: 10,
    padding: 14,
    marginBottom: 20,
    fontSize: 16,
    color: CORES.verde,
  },

  botao: {
    backgroundColor: CORES.verde,
    padding: 16,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 5,
  },

  textoBotao: {
    color: CORES.branco,
    fontSize: 16,
    fontWeight: 'bold',
  },

  botaoCancelar: {
    backgroundColor: 'transparent',
    borderWidth: 1,
    borderColor: CORES.verde,
    padding: 15,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 12,
  },

  textoCancelar: {
    color: CORES.verde,
    fontSize: 16,
    fontWeight: 'bold',
  },
});