import React, { useState } from 'react';
import {
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  Alert,
} from 'react-native';

export default function CadastroMatriculaScreen({
  matriculas,
  setMatriculas,
  alunos = [],
  cursos = [],
  navegar,
}) {
  const [aluno, setAluno] = useState('');
  const [curso, setCurso] = useState('');
  const [ano, setAno] = useState('');

  function cadastrar() {
    if (!aluno || !curso || !ano.trim()) {
      Alert.alert('Atenção', 'Preencha todos os campos.');
      return;
    }

    setMatriculas([
      ...matriculas,
      {
        id: Date.now(),
        aluno,
        curso,
        ano,
      },
    ]);

    Alert.alert('Sucesso', 'Matrícula cadastrada!');
    setAluno('');
    setCurso('');
    setAno('');
  }

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.titulo}>Cadastrar Matrícula</Text>

      <Text style={styles.label}>Aluno</Text>

      {alunos.map((item) => (
        <TouchableOpacity
          key={item.id}
          style={[
            styles.opcao,
            aluno === item.nome && styles.selecionado,
          ]}
          onPress={() => setAluno(item.nome)}
        >
          <Text
            style={[
              styles.textoOpcao,
              aluno === item.nome && styles.textoSelecionado,
            ]}
          >
            {item.nome}
          </Text>
        </TouchableOpacity>
      ))}

      <Text style={styles.label}>Curso</Text>

      {cursos.map((item) => (
        <TouchableOpacity
          key={item.id}
          style={[
            styles.opcao,
            curso === item.nome && styles.selecionado,
          ]}
          onPress={() => setCurso(item.nome)}
        >
          <Text
            style={[
              styles.textoOpcao,
              curso === item.nome && styles.textoSelecionado,
            ]}
          >
            {item.nome}
          </Text>
        </TouchableOpacity>
      ))}

      <TextInput
        style={styles.input}
        placeholder="Ano da matrícula"
        value={ano}
        onChangeText={setAno}
        keyboardType="numeric"
      />

      <TouchableOpacity style={styles.botao} onPress={cadastrar}>
        <Text style={styles.textoBotao}>CADASTRAR</Text>
      </TouchableOpacity>

      <TouchableOpacity onPress={() => navegar('consultaMatriculas')}>
        <Text style={styles.voltar}>Consultar matrículas</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    padding: 25,
    backgroundColor: '#FFFAFA',
  },
  titulo: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#0D2C1D',
    marginBottom: 25,
  },
  label: {
    fontWeight: 'bold',
    color: '#0D2C1D',
    marginBottom: 10,
  },
  opcao: {
    backgroundColor: '#FFF',
    borderWidth: 1,
    borderColor: '#D5DDD8',
    padding: 14,
    borderRadius: 10,
    marginBottom: 10,
  },
  selecionado: {
    backgroundColor: '#0D2C1D',
  },
  textoOpcao: {
    color: '#0D2C1D',
    fontWeight: 'bold',
  },
  textoSelecionado: {
    color: '#FFF',
  },
  input: {
    backgroundColor: '#FFF',
    borderWidth: 1,
    borderColor: '#D5DDD8',
    borderRadius: 10,
    padding: 14,
    marginVertical: 15,
  },
  botao: {
    backgroundColor: '#0D2C1D',
    padding: 16,
    borderRadius: 10,
    alignItems: 'center',
  },
  textoBotao: {
    color: '#FFF',
    fontWeight: 'bold',
  },
  voltar: {
    textAlign: 'center',
    color: '#666',
    marginTop: 20,
  },
});