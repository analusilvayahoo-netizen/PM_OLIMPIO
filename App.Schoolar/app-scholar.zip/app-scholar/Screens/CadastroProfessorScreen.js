import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
} from 'react-native';

export default function CadastroProfessorScreen({
  navegar,
  professores,
  setProfessores,
}) {
  const [nome, setNome] = useState('');
  const [email, setEmail] = useState('');
  const [disciplina, setDisciplina] = useState('');

  function cadastrar() {
    if (!nome || !email || !disciplina) {
      alert('Preencha todos os campos.');
      return;
    }

    const novoProfessor = {
      id: Date.now(),
      nome,
      email,
      disciplina,
    };

    setProfessores([...professores, novoProfessor]);

    alert('Professor cadastrado com sucesso!');

    setNome('');
    setEmail('');
    setDisciplina('');
  }

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.titulo}>Cadastro de Professor</Text>

      <Text style={styles.label}>Nome</Text>
      <TextInput
        style={styles.input}
        placeholder="Nome completo"
        value={nome}
        onChangeText={setNome}
      />

      <Text style={styles.label}>E-mail</Text>
      <TextInput
        style={styles.input}
        placeholder="E-mail"
        value={email}
        onChangeText={setEmail}
        keyboardType="email-address"
      />

      <Text style={styles.label}>Disciplina</Text>
      <TextInput
        style={styles.input}
        placeholder="Disciplina"
        value={disciplina}
        onChangeText={setDisciplina}
      />

      <TouchableOpacity style={styles.botao} onPress={cadastrar}>
        <Text style={styles.botaoTexto}>CADASTRAR</Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={styles.secundario}
        onPress={() => navegar('consultaProfessores')}
      >
        <Text style={styles.secundarioTexto}>
          CONSULTAR PROFESSORES
        </Text>
      </TouchableOpacity>

      <TouchableOpacity onPress={() => navegar('dashboard')}>
        <Text style={styles.voltar}>Voltar ao menu</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFAFA',
    padding: 20,
  },
  titulo: {
    fontSize: 27,
    fontWeight: 'bold',
    color: '#0D2C1D',
    marginBottom: 25,
  },
  label: {
    fontWeight: 'bold',
    marginBottom: 7,
  },
  input: {
    backgroundColor: '#FFF',
    borderWidth: 1,
    borderColor: '#CCC',
    borderRadius: 10,
    padding: 14,
    marginBottom: 18,
  },
  botao: {
    backgroundColor: '#0D2C1D',
    padding: 16,
    borderRadius: 10,
    alignItems: 'center',
  },
  botaoTexto: {
    color: '#FFF',
    fontWeight: 'bold',
  },
  secundario: {
    borderWidth: 1,
    borderColor: '#0D2C1D',
    padding: 15,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 12,
  },
  secundarioTexto: {
    color: '#0D2C1D',
    fontWeight: 'bold',
  },
  voltar: {
    textAlign: 'center',
    color: '#0D2C1D',
    marginTop: 20,
    marginBottom: 30,
  },
});