import React, { useState } from 'react';
import {
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  Alert,
} from 'react-native';

export default function EditarDisciplinaScreen({
  disciplina,
  disciplinas,
  setDisciplinas,
  cursos = [],
  navegar,
}) {
  const [nome, setNome] = useState(disciplina?.nome || '');
  const [curso, setCurso] = useState(disciplina?.curso || '');

  function salvar() {
    if (!nome.trim() || !curso) {
      Alert.alert('Atenção', 'Preencha os dados.');
      return;
    }

    setDisciplinas(
      disciplinas.map((item) =>
        item.id === disciplina.id
          ? { ...item, nome: nome.trim(), curso }
          : item
      )
    );

    Alert.alert('Sucesso', 'Disciplina atualizada!');
    navegar('consultaDisciplinas');
  }

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.titulo}>Editar Disciplina</Text>

      <TextInput
        style={styles.input}
        placeholder="Nome da disciplina"
        value={nome}
        onChangeText={setNome}
      />

      <Text style={styles.label}>Curso</Text>

      {cursos.map((item) => (
        <TouchableOpacity
          key={item.id}
          style={[
            styles.opcao,
            curso === item.nome && styles.selecionado,
          ]}
          onPress={() => setCurso(item.nome)}
        >
          <Text
            style={[
              styles.textoOpcao,
              curso === item.nome && styles.textoSelecionado,
            ]}
          >
            {item.nome}
          </Text>
        </TouchableOpacity>
      ))}

      <TouchableOpacity style={styles.botao} onPress={salvar}>
        <Text style={styles.textoBotao}>SALVAR ALTERAÇÕES</Text>
      </TouchableOpacity>

      <TouchableOpacity onPress={() => navegar('consultaDisciplinas')}>
        <Text style={styles.voltar}>Cancelar</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    padding: 25,
    backgroundColor: '#FFFAFA',
  },
  titulo: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#0D2C1D',
    marginBottom: 25,
  },
  label: {
    fontWeight: 'bold',
    color: '#0D2C1D',
    marginBottom: 10,
  },
  input: {
    backgroundColor: '#FFF',
    borderWidth: 1,
    borderColor: '#D5DDD8',
    borderRadius: 10,
    padding: 14,
    marginBottom: 20,
  },
  opcao: {
    backgroundColor: '#FFF',
    borderWidth: 1,
    borderColor: '#D5DDD8',
    padding: 14,
    borderRadius: 10,
    marginBottom: 10,
  },
  selecionado: {
    backgroundColor: '#0D2C1D',
  },
  textoOpcao: {
    color: '#0D2C1D',
    fontWeight: 'bold',
  },
  textoSelecionado: {
    color: '#FFF',
  },
  botao: {
    backgroundColor: '#0D2C1D',
    padding: 16,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 15,
  },
  textoBotao: {
    color: '#FFF',
    fontWeight: 'bold',
  },
  voltar: {
    textAlign: 'center',
    marginTop: 20,
    color: '#666',
  },
});