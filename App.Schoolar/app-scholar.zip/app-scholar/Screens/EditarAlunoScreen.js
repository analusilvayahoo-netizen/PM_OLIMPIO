import React, { useState } from 'react';

import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
} from 'react-native';

export default function EditarAlunoScreen({
  navegar,
  aluno,
  alunos,
  setAlunos,
}) {

  const [nome, setNome] = useState(aluno?.nome || '');
  const [email, setEmail] = useState(aluno?.email || '');
  const [curso, setCurso] = useState(aluno?.curso || '');
  const [turma, setTurma] = useState(aluno?.turma || '');

  function salvar() {

    const atualizados = alunos.map(item => {

      if (item.id === aluno.id) {
        return {
          ...item,
          nome,
          email,
          curso,
          turma,
        };
      }

      return item;
    });

    setAlunos(atualizados);

    alert('Aluno atualizado com sucesso!');

    navegar('consultaAlunos');
  }

  return (
    <ScrollView style={styles.container}>

      <Text style={styles.titulo}>
        Editar Aluno
      </Text>

      <Text style={styles.label}>Nome</Text>

      <TextInput
        style={styles.input}
        value={nome}
        onChangeText={setNome}
      />

      <Text style={styles.label}>E-mail</Text>

      <TextInput
        style={styles.input}
        value={email}
        onChangeText={setEmail}
      />

      <Text style={styles.label}>Curso</Text>

      <TextInput
        style={styles.input}
        value={curso}
        onChangeText={setCurso}
      />

      <Text style={styles.label}>Turma</Text>

      <TextInput
        style={styles.input}
        value={turma}
        onChangeText={setTurma}
      />

      <TouchableOpacity
        style={styles.botao}
        onPress={salvar}
      >
        <Text style={styles.botaoTexto}>
          SALVAR ALTERAÇÕES
        </Text>
      </TouchableOpacity>

      <TouchableOpacity
        onPress={() => navegar('consultaAlunos')}
      >
        <Text style={styles.voltar}>
          Cancelar
        </Text>
      </TouchableOpacity>

    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFAFA',
    padding: 20,
  },

  titulo: {
    fontSize: 27,
    fontWeight: 'bold',
    color: '#0D2C1D',
    marginBottom: 25,
  },

  label: {
    fontWeight: 'bold',
    marginBottom: 7,
  },

  input: {
    backgroundColor: '#FFF',
    borderWidth: 1,
    borderColor: '#CCC',
    borderRadius: 10,
    padding: 14,
    marginBottom: 18,
  },

  botao: {
    backgroundColor: '#0D2C1D',
    padding: 16,
    borderRadius: 10,
    alignItems: 'center',
  },

  botaoTexto: {
    color: '#FFF',
    fontWeight: 'bold',
  },

  voltar: {
    textAlign: 'center',
    color: '#0D2C1D',
    marginTop: 20,
  },
});