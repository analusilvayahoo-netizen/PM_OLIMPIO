import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
} from 'react-native';

export default function ConsultaCursosScreen({
  navegar,
  cursos,
  setCursos,
}) {
  const [pesquisa, setPesquisa] = useState('');

  const filtrados = cursos.filter(curso =>
    curso.nome.toLowerCase().includes(
      pesquisa.toLowerCase()
    )
  );

  function excluir(id) {
    setCursos(
      cursos.filter(curso => curso.id !== id)
    );
  }

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.titulo}>Consulta de Cursos</Text>

      <TextInput
        style={styles.input}
        placeholder="Pesquisar curso..."
        value={pesquisa}
        onChangeText={setPesquisa}
      />

      <TouchableOpacity
        style={styles.cadastrar}
        onPress={() => navegar('cadastroCurso')}
      >
        <Text style={styles.cadastrarTexto}>
          + CADASTRAR CURSO
        </Text>
      </TouchableOpacity>

      {filtrados.map(curso => (
        <View key={curso.id} style={styles.card}>
          <Text style={styles.nome}>{curso.nome}</Text>

          <Text style={styles.descricao}>
            {curso.descricao}
          </Text>

          <View style={styles.acoes}>
            <TouchableOpacity
              style={styles.editar}
              onPress={() =>
                navegar('editarCurso', curso)
              }
            >
              <Text style={styles.acaoTexto}>EDITAR</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.excluir}
              onPress={() => excluir(curso.id)}
            >
              <Text style={styles.acaoTexto}>EXCLUIR</Text>
            </TouchableOpacity>
          </View>
        </View>
      ))}

      {filtrados.length === 0 && (
        <Text style={styles.vazio}>
          Nenhum curso encontrado.
        </Text>
      )}

      <TouchableOpacity onPress={() => navegar('dashboard')}>
        <Text style={styles.voltar}>Voltar ao menu</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFAFA',
    padding: 20,
  },
  titulo: {
    fontSize: 27,
    fontWeight: 'bold',
    color: '#0D2C1D',
    marginBottom: 20,
  },
  input: {
    backgroundColor: '#FFF',
    borderWidth: 1,
    borderColor: '#CCC',
    borderRadius: 10,
    padding: 14,
    marginBottom: 12,
  },
  cadastrar: {
    backgroundColor: '#0D2C1D',
    padding: 15,
    borderRadius: 10,
    alignItems: 'center',
    marginBottom: 20,
  },
  cadastrarTexto: {
    color: '#FFF',
    fontWeight: 'bold',
  },
  card: {
    backgroundColor: '#FFF',
    borderWidth: 1,
    borderColor: '#DDD',
    borderRadius: 10,
    padding: 16,
    marginBottom: 15,
  },
  nome: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0D2C1D',
    marginBottom: 8,
  },
  descricao: {
    color: '#555',
    lineHeight: 20,
  },
  acoes: {
    flexDirection: 'row',
    gap: 10,
    marginTop: 15,
  },
  editar: {
    backgroundColor: '#0D2C1D',
    padding: 10,
    borderRadius: 7,
    flex: 1,
    alignItems: 'center',
  },
  excluir: {
    backgroundColor: '#777',
    padding: 10,
    borderRadius: 7,
    flex: 1,
    alignItems: 'center',
  },
  acaoTexto: {
    color: '#FFF',
    fontWeight: 'bold',
  },
  vazio: {
    textAlign: 'center',
    color: '#777',
    marginTop: 20,
  },
  voltar: {
    textAlign: 'center',
    color: '#0D2C1D',
    marginTop: 15,
    marginBottom: 30,
  },
});