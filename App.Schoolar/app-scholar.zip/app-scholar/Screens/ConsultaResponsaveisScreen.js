import React, { useState } from 'react';
import {
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  View,
  StyleSheet,
  Alert,
} from 'react-native';

export default function ConsultaResponsaveisScreen({
  responsaveis,
  setResponsaveis,
  navegar,
}) {
  const [busca, setBusca] = useState('');

  const lista = responsaveis.filter((item) =>
    `${item.nome} ${item.aluno} ${item.telefone}`
      .toLowerCase()
      .includes(busca.toLowerCase())
  );

  function excluir(id) {
    Alert.alert('Excluir', 'Deseja excluir este responsável?', [
      { text: 'Cancelar', style: 'cancel' },
      {
        text: 'Excluir',
        onPress: () =>
          setResponsaveis(
            responsaveis.filter((item) => item.id !== id)
          ),
      },
    ]);
  }

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.titulo}>Consultar Responsáveis</Text>

      <TextInput
        style={styles.input}
        placeholder="Pesquisar..."
        value={busca}
        onChangeText={setBusca}
      />

      {lista.map((item) => (
        <View style={styles.card} key={item.id}>
          <Text style={styles.nome}>{item.nome}</Text>
          <Text>Telefone: {item.telefone}</Text>
          <Text>Aluno: {item.aluno}</Text>

          <TouchableOpacity
            style={styles.editar}
            onPress={() => navegar('editarResponsavel', item)}
          >
            <Text style={styles.textoBotao}>EDITAR</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.excluir}
            onPress={() => excluir(item.id)}
          >
            <Text style={styles.textoBotao}>EXCLUIR</Text>
          </TouchableOpacity>
        </View>
      ))}

      <TouchableOpacity
        style={styles.botao}
        onPress={() => navegar('cadastroResponsavel')}
      >
        <Text style={styles.textoBotao}>NOVO RESPONSÁVEL</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flexGrow: 1, padding: 25, backgroundColor: '#FFFAFA' },
  titulo: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#0D2C1D',
    marginBottom: 20,
  },
  input: {
    backgroundColor: '#FFF',
    borderWidth: 1,
    borderColor: '#D5DDD8',
    borderRadius: 10,
    padding: 14,
    marginBottom: 20,
  },
  card: {
    backgroundColor: '#FFF',
    padding: 18,
    borderRadius: 12,
    marginBottom: 15,
  },
  nome: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0D2C1D',
    marginBottom: 8,
  },
  editar: {
    backgroundColor: '#0D2C1D',
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 12,
  },
  excluir: {
    backgroundColor: '#8B0000',
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 8,
  },
  botao: {
    backgroundColor: '#0D2C1D',
    padding: 16,
    borderRadius: 10,
    alignItems: 'center',
  },
  textoBotao: {
    color: '#FFF',
    fontWeight: 'bold',
  },
});