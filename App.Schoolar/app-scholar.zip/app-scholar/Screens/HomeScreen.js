import React from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Image,
} from 'react-native';

export default function HomeScreen({ navegar, logo }) {
  return (
    <View style={styles.container}>

      {logo && (
        <Image
          source={logo}
          style={styles.logo}
          resizeMode="contain"
        />
      )}

      <Text style={styles.titulo}>DAVINCI</Text>

      <Text style={styles.subtitulo}>
        App Scholar
      </Text>

      <TouchableOpacity
        style={styles.botao}
        onPress={() => navegar('login')}
      >
        <Text style={styles.textoBotao}>ENTRAR</Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={styles.botaoSecundario}
        onPress={() => navegar('sobre')}
      >
        <Text style={styles.textoBotaoSecundario}>
          SOBRE O APLICATIVO
        </Text>
      </TouchableOpacity>

    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#FFFAFA',
    padding: 25,
  },

  logo: {
    width: 180,
    height: 100,
    marginBottom: 15,
  },

  titulo: {
    fontSize: 38,
    fontWeight: 'bold',
    color: '#0D2C1D',
  },

  subtitulo: {
    fontSize: 20,
    color: '#666',
    marginBottom: 40,
  },

  botao: {
    width: '90%',
    backgroundColor: '#0D2C1D',
    padding: 16,
    borderRadius: 10,
    alignItems: 'center',
    marginBottom: 15,
  },

  textoBotao: {
    color: '#FFF',
    fontSize: 16,
    fontWeight: 'bold',
  },

  botaoSecundario: {
    width: '90%',
    borderWidth: 1,
    borderColor: '#0D2C1D',
    padding: 15,
    borderRadius: 10,
    alignItems: 'center',
  },

  textoBotaoSecundario: {
    color: '#0D2C1D',
    fontWeight: 'bold',
  },
});