import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
} from 'react-native';

export default function EditarProfessorScreen({
  navegar,
  professor,
  professores,
  setProfessores,
}) {
  const [nome, setNome] = useState(professor?.nome || '');
  const [email, setEmail] = useState(professor?.email || '');
  const [disciplina, setDisciplina] = useState(
    professor?.disciplina || ''
  );

  function salvar() {
    const atualizados = professores.map(item => {
      if (item.id === professor.id) {
        return {
          ...item,
          nome,
          email,
          disciplina,
        };
      }

      return item;
    });

    setProfessores(atualizados);

    alert('Professor atualizado com sucesso!');

    navegar('consultaProfessores');
  }

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.titulo}>Editar Professor</Text>

      <Text style={styles.label}>Nome</Text>
      <TextInput
        style={styles.input}
        value={nome}
        onChangeText={setNome}
      />

      <Text style={styles.label}>E-mail</Text>
      <TextInput
        style={styles.input}
        value={email}
        onChangeText={setEmail}
      />

      <Text style={styles.label}>Disciplina</Text>
      <TextInput
        style={styles.input}
        value={disciplina}
        onChangeText={setDisciplina}
      />

      <TouchableOpacity style={styles.botao} onPress={salvar}>
        <Text style={styles.botaoTexto}>
          SALVAR ALTERAÇÕES
        </Text>
      </TouchableOpacity>

      <TouchableOpacity
        onPress={() => navegar('consultaProfessores')}
      >
        <Text style={styles.voltar}>Cancelar</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFAFA',
    padding: 20,
  },
  titulo: {
    fontSize: 27,
    fontWeight: 'bold',
    color: '#0D2C1D',
    marginBottom: 25,
  },
  label: {
    fontWeight: 'bold',
    marginBottom: 7,
  },
  input: {
    backgroundColor: '#FFF',
    borderWidth: 1,
    borderColor: '#CCC',
    borderRadius: 10,
    padding: 14,
    marginBottom: 18,
  },
  botao: {
    backgroundColor: '#0D2C1D',
    padding: 16,
    borderRadius: 10,
    alignItems: 'center',
  },
  botaoTexto: {
    color: '#FFF',
    fontWeight: 'bold',
  },
  voltar: {
    textAlign: 'center',
    color: '#0D2C1D',
    marginTop: 20,
  },
});