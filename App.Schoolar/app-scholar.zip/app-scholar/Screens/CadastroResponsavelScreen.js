import React, { useState } from 'react';
import {
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  Alert,
} from 'react-native';

export default function CadastroResponsavelScreen({
  responsaveis,
  setResponsaveis,
  alunos = [],
  navegar,
}) {
  const [nome, setNome] = useState('');
  const [telefone, setTelefone] = useState('');
  const [aluno, setAluno] = useState('');

  function cadastrar() {
    if (!nome.trim() || !telefone.trim() || !aluno) {
      Alert.alert('Atenção', 'Preencha todos os campos.');
      return;
    }

    setResponsaveis([
      ...responsaveis,
      {
        id: Date.now(),
        nome: nome.trim(),
        telefone: telefone.trim(),
        aluno,
      },
    ]);

    Alert.alert('Sucesso', 'Responsável cadastrado!');
    setNome('');
    setTelefone('');
    setAluno('');
  }

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.titulo}>Cadastrar Responsável</Text>

      <TextInput
        style={styles.input}
        placeholder="Nome"
        value={nome}
        onChangeText={setNome}
      />

      <TextInput
        style={styles.input}
        placeholder="Telefone"
        value={telefone}
        onChangeText={setTelefone}
        keyboardType="phone-pad"
      />

      <Text style={styles.label}>Aluno</Text>

      {alunos.map((item) => (
        <TouchableOpacity
          key={item.id}
          style={[
            styles.opcao,
            aluno === item.nome && styles.selecionado,
          ]}
          onPress={() => setAluno(item.nome)}
        >
          <Text
            style={[
              styles.textoOpcao,
              aluno === item.nome && styles.textoSelecionado,
            ]}
          >
            {item.nome}
          </Text>
        </TouchableOpacity>
      ))}

      <TouchableOpacity style={styles.botao} onPress={cadastrar}>
        <Text style={styles.textoBotao}>CADASTRAR</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    padding: 25,
    backgroundColor: '#FFFAFA',
  },
  titulo: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#0D2C1D',
    marginBottom: 25,
  },
  input: {
    backgroundColor: '#FFF',
    borderWidth: 1,
    borderColor: '#D5DDD8',
    borderRadius: 10,
    padding: 14,
    marginBottom: 15,
  },
  label: {
    fontWeight: 'bold',
    color: '#0D2C1D',
    marginBottom: 10,
  },
  opcao: {
    backgroundColor: '#FFF',
    borderWidth: 1,
    borderColor: '#D5DDD8',
    padding: 14,
    borderRadius: 10,
    marginBottom: 10,
  },
  selecionado: {
    backgroundColor: '#0D2C1D',
  },
  textoOpcao: {
    color: '#0D2C1D',
    fontWeight: 'bold',
  },
  textoSelecionado: {
    color: '#FFF',
  },
  botao: {
    backgroundColor: '#0D2C1D',
    padding: 16,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 15,
  },
  textoBotao: {
    color: '#FFF',
    fontWeight: 'bold',
  },
});